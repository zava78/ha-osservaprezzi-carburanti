"""Sensori per l'integrazione Osservaprezzi Carburanti.

Questo modulo crea sensori per ogni impianto e per tipo di carburante usando
DataUpdateCoordinator per gestire il polling e la memorizzazione dei dati.
"""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

from homeassistant.components.sensor import (
    SensorEntity,
    SensorEntityDescription,
    SensorStateClass,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import ATTR_ATTRIBUTION, CONF_NAME
from homeassistant.core import HomeAssistant
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.entity import DeviceInfo
from homeassistant.helpers.typing import StateType
from homeassistant.helpers.update_coordinator import (
    DataUpdateCoordinator,
    UpdateFailed,
)
from homeassistant.config_entries import ConfigEntry

from .const import (
    API_URL_TEMPLATE,
    BRAND_LOGOS,
    DATA_COORDINATORS,
    DEFAULT_ICON,
    DEFAULT_SCAN_INTERVAL,
    REQUEST_TIMEOUT,
    DOMAIN,
    scan_interval_td,
)
from .helpers import find_coordinates

_LOGGER = logging.getLogger(__name__)


def _normalize(text: Optional[str]) -> str:
    if not text:
        return "unknown"
    return "".join(c if c.isalnum() else "_" for c in text.lower())


def _format_address(data: Dict[str, Any]) -> str:
    # Tenta di estrarre un indirizzo leggibile dai campi noti, altrimenti usa una fallback
    for key in ("address", "indirizzo", "street"):
        if key in data and data[key]:
            return data[key]

    parts = []
    for k in ("street", "civic", "city", "municipality", "prov", "province", "zip"):
        v = data.get(k) or data.get(k.upper())
        if v:
            parts.append(str(v))
    if parts:
        return ", ".join(parts)
    return data.get("name") or data.get("description") or ""


class StationDataUpdateCoordinator(DataUpdateCoordinator):
    """Coordinator per ottenere i dati dell'impianto dall'API Osservaprezzi."""

    def __init__(self, hass: HomeAssistant, station_id: int, scan_interval: int):
        self.station_id = station_id
        super().__init__(
            hass,
            _LOGGER,
            name=f"osservaprezzi_{station_id}",
            update_interval=scan_interval_td(scan_interval),
        )

    async def _async_update_data(self) -> Dict[str, Any]:
        """Recupera i dati dall'API e ritorna il JSON."""
        url = API_URL_TEMPLATE.format(id=self.station_id)
        _LOGGER.debug("Richiedo dati per impianto %s da %s", self.station_id, url)

        session = async_get_clientsession(self.hass)
        try:
            async with session.get(url, timeout=REQUEST_TIMEOUT) as resp:
                if resp.status != 200:
                    text = await resp.text()
                    raise UpdateFailed(f"HTTP {resp.status}: {text}")

                data = await resp.json()
                if not isinstance(data, dict):
                    raise UpdateFailed("Unexpected JSON structure")

                _LOGGER.debug("Fetched data for %s: %s", self.station_id, data.keys())
                return data
        except Exception as err:  # noqa: BLE001 - vogliamo loggare e rilanciare
            _LOGGER.exception("Errore recupero dati per impianto %s: %s", self.station_id, err)
            raise UpdateFailed(err)


async def async_setup_platform(
        hass: HomeAssistant,
        config: Dict[str, Any],
        async_add_entities,
        discovery_info=None,
) -> None:
    """Configurazione via YAML: crea sensori per le stazioni elencate nella configurazione.

    Schema YAML supportato (vedi README):
        osservaprezzi_carburanti:
            scan_interval: 7200
            stations:
                - id: 48524
                  name: "Distributore Ener Coop"
    """
    yaml = hass.data.get(DOMAIN, {}).get("yaml_config", {}) or {}
    stations = yaml.get("stations", [])
    scan_interval = yaml.get("scan_interval", DEFAULT_SCAN_INTERVAL)

    hass.data.setdefault(DATA_COORDINATORS, {})

    entities: List[SensorEntity] = []

    for station in stations:
        station_id = station.get("id")
        if station_id is None:
            _LOGGER.warning("Ignoro impianto senza id nella configurazione YAML: %s", station)
            continue
        try:
            station_id_int = int(station_id)
        except (TypeError, ValueError):
            _LOGGER.warning("Id impianto non valido '%s', ignoro", station_id)
            continue

        coordinator = StationDataUpdateCoordinator(hass, station_id_int, scan_interval)
        # memorizza il coordinator per riferimenti futuri
        hass.data[DATA_COORDINATORS][station_id_int] = coordinator

        # Esegui un primo refresh (pattern non bloccante: aggiorna ora per popolare le entità)
        await coordinator.async_request_refresh()

        data = coordinator.data or {}

        # Crea il sensore meta (uno per impianto)
        entities.append(StationMetaSensor(coordinator, station))

        # Estrai la lista dei carburanti in modo robusto
        fuels = data.get("fuels") or data.get("carburanti") or []
        if not isinstance(fuels, list):
            fuels = []

        if fuels:
            for fuel in fuels:
                name = fuel.get("name") or fuel.get("fuel") or fuel.get("description")
                is_self = bool(fuel.get("isSelf") or fuel.get("is_self") or False)
                entities.append(FuelPriceSensor(coordinator, station, name, is_self))
        else:
            # Nessun carburante restituito: crea un sensore generico per segnalare l'indisponibilità
            entities.append(FuelPriceSensor(coordinator, station, None, True))

    if entities:
        async_add_entities(entities, True)


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry, async_add_entities) -> None:
    """Configura i sensori per una config entry.

    Una singola config entry può contenere più impianti in `entry.data['stations']`.
    """
    data = entry.data or {}
    stations = data.get("stations")
    scan_interval = data.get("scan_interval") or DEFAULT_SCAN_INTERVAL

    if not stations:
        # Compatibilità retrocompatibile: supporta entry con un singolo impianto
        station_id = data.get("station_id") or data.get("id")
        if station_id is None:
            _LOGGER.error("La config entry %s manca di station_id", entry.entry_id)
            return
        stations = [{"id": int(station_id), "name": data.get("name") or ""}]

    hass.data.setdefault(DATA_COORDINATORS, {})

    entities: List[SensorEntity] = []

    for st in stations:
        try:
            station_id_int = int(st.get("id"))
        except (TypeError, ValueError):
            _LOGGER.warning("Ignoro id impianto non valido nella entry %s: %s", entry.entry_id, st)
            continue

        coordinator = StationDataUpdateCoordinator(hass, station_id_int, scan_interval)
        # indicizza i coordinatori con (entry_id, station_id) per consentire più impianti nella stessa entry
        hass.data[DATA_COORDINATORS][(entry.entry_id, station_id_int)] = coordinator

        # rinnova immediatamente (refresh iniziale per la entry)
        try:
            await coordinator.async_config_entry_first_refresh()
        except Exception as err:
            _LOGGER.warning("Refresh iniziale fallito per l'impianto %s: %s", station_id_int, err)

        entities.append(StationMetaSensor(coordinator, {"id": station_id_int, "name": st.get("name")}, entry.entry_id))

        fuels = coordinator.data.get("fuels") or coordinator.data.get("carburanti") or []
        if isinstance(fuels, list) and fuels:
            for fuel in fuels:
                fname = fuel.get("name") or fuel.get("fuel") or fuel.get("description")
                is_self = bool(fuel.get("isSelf") or fuel.get("is_self") or False)
                entities.append(FuelPriceSensor(coordinator, {"id": station_id_int, "name": st.get("name")}, fname, is_self, entry.entry_id))
        else:
            entities.append(FuelPriceSensor(coordinator, {"id": station_id_int, "name": st.get("name")}, None, True, entry.entry_id))

    if entities:
        async_add_entities(entities, True)


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload sensors for a config entry."""
    # rimuove i coordinatori associati a questa entry
    coordinators = hass.data.get(DATA_COORDINATORS, {})
    to_remove = [k for k in coordinators.keys() if isinstance(k, tuple) and k[0] == entry.entry_id]
    for k in to_remove:
        coordinators.pop(k, None)
    return True


class StationMetaSensor(SensorEntity):
    """Sensore che espone i metadati dell'impianto come attributi."""

    _attr_icon = DEFAULT_ICON

    def __init__(self, coordinator: StationDataUpdateCoordinator, station_cfg: Dict[str, Any], entry_id: str | None = None):
        self.coordinator = coordinator
        self.station_cfg = station_cfg
        self.entry_id = entry_id
        self.station_id = int(station_cfg.get("id"))
        configured_name = station_cfg.get("name")
        self._name = configured_name or f"Osservaprezzi {self.station_id}"
        # Includi l'entry id in `unique_id` quando disponibile per evitare collisioni tra entry
        if self.entry_id:
            self._unique_id = f"{DOMAIN}_{self.entry_id}_{self.station_id}_meta"
        else:
            self._unique_id = f"{DOMAIN}_{self.station_id}_meta"
        # Fornisce una descrizione dell'entità per il sensore meta. Non si applica
        # una `device_class` specifica, ma esporre la descrizione aiuta le versioni
        # più recenti di Home Assistant e il registro delle entità a riconoscerlo.
        self.entity_description = SensorEntityDescription(
            key=self._unique_id,
            name=self._name,
            translation_key="station_meta",
            entity_category=None,
        )
        # Contrassegna come diagnostico nel registro tramite i metadati dell'entità
        # (Home Assistant può mostrarlo come informativo). Non impostiamo una
        # `device_class` perché questo sensore espone più campi di metadata.
        try:
            # Newer HA versions may support entity_category in descriptions
            self.entity_description.entity_category = None
        except Exception:
            pass

    @property
    def name(self) -> str:
        return self._name

    @property
    def unique_id(self) -> str:
        return self._unique_id

    @property
    def available(self) -> bool:
        return self.coordinator.last_update_success

    @property
    def native_value(self) -> StateType:
        # Meta sensor has no numeric state; use station id
        return str(self.station_id)

    @property
    def extra_state_attributes(self) -> Dict[str, Any]:
        data = self.coordinator.data or {}
        attrs: Dict[str, Any] = {}
        attrs["company"] = data.get("company") or data.get("gestore")
        attrs["name"] = data.get("name") or data.get("description") or self._name
        attrs["address"] = _format_address(data)
        attrs["brand"] = data.get("brand")
        attrs["raw"] = data
        # Se disponibili, aggiungi latitudine/longitudine come attributi separati
        coords = find_coordinates(data)
        if coords:
            attrs["latitude"] = coords[0]
            attrs["longitude"] = coords[1]

        if not self.available:
            attrs["error"] = "unavailable"
        return attrs

    @property
    def device_info(self) -> DeviceInfo:
        # Usa l'identificatore legato all'entry quando disponibile così ogni
        # entry configurata ottiene la propria istanza device per lo stesso
        # impianto reale.
        identifier = f"{self.entry_id}_{self.station_id}" if self.entry_id else str(self.station_id)
        return DeviceInfo(
            identifiers={(DOMAIN, identifier)},
            name=self._name,
            manufacturer="Osservaprezzi / MIMIT",
        )


class FuelPriceSensor(SensorEntity):
    """Sensor exposing price for a fuel at a station in self/servito mode."""

    _attr_icon = DEFAULT_ICON

    def __init__(
        self,
        coordinator: StationDataUpdateCoordinator,
        station_cfg: Dict[str, Any],
        fuel_name: Optional[str],
        is_self: bool,
        entry_id: str | None = None,
    ) -> None:
        self.coordinator = coordinator
        self.station_cfg = station_cfg
        self.entry_id = entry_id
        self.station_id = int(station_cfg.get("id"))
        self.configured_name = station_cfg.get("name")
        self.fuel_name = fuel_name or "unknown"
        self.is_self = is_self
        mode = "self" if is_self else "attended"
        normalized = _normalize(self.fuel_name)
        # Unique id includes entry id when available to prevent collisions
        if entry_id:
            self._unique_id = f"{DOMAIN}_{entry_id}_{self.station_id}_{normalized}_{mode}"
        else:
            self._unique_id = f"{DOMAIN}_{self.station_id}_{normalized}_{mode}"

        base_name = self.configured_name or (coordinator.data or {}).get("name") or f"Station {self.station_id}"
        # Produci un nome entità più chiaro e leggibile per l'utente
        mode_label = "Self" if is_self else "Servito"
        self._name = f"{base_name} — {self.fuel_name} ({mode_label})"

        # Usa SensorEntityDescription per fornire metadati (unità nativa, state_class)
        self.entity_description = SensorEntityDescription(
            key=self._unique_id,
            name=self._name,
            native_unit_of_measurement="€/l",
            state_class=SensorStateClass.MEASUREMENT,
            translation_key="fuel_price",
            device_class=None,
        )

        # Imposta anche gli attributi interni moderni per compatibilità
        self._attr_native_unit_of_measurement = "€/l"
        self._attr_state_class = SensorStateClass.MEASUREMENT

    @property
    def name(self) -> str:
        return self._name

    @property
    def unique_id(self) -> str:
        return self._unique_id

    @property
    def available(self) -> bool:
        return self.coordinator.last_update_success

    @property
    def native_value(self) -> StateType:
        data = self.coordinator.data or {}
        fuels = data.get("fuels") or data.get("carburanti") or []
        if not fuels:
            return None
        for f in fuels:
            candidate = f.get("name") or f.get("fuel") or f.get("description")
            candidate_is_self = bool(f.get("isSelf") or f.get("is_self") or False)
            if str(candidate).lower() == str(self.fuel_name).lower() and candidate_is_self == self.is_self:
                price = f.get("price") or f.get("prezzo")
                try:
                    return float(price) if price is not None else None
                except (TypeError, ValueError):
                    return None
        # Fallback: prova a corrispondere solo per nome
        for f in fuels:
            candidate = f.get("name") or f.get("fuel") or f.get("description")
            if str(candidate).lower() == str(self.fuel_name).lower():
                price = f.get("price") or f.get("prezzo")
                try:
                    return float(price) if price is not None else None
                except (TypeError, ValueError):
                    return None
        return None

    @property
    def unit_of_measurement(self) -> Optional[str]:
        # Supponiamo €/l per i carburanti liquidi; per kg (metano) l'API di solito specifica l'unità.
        return "€/l"

    @property
    def native_unit_of_measurement(self) -> Optional[str]:
        # Home Assistant 2025.12 preferisce `native_unit_of_measurement` per SensorEntity.
        # Manteniamo `unit_of_measurement` per retrocompatibilità ma forniamo la
        # proprietà moderna per assicurare compatibilità con le versioni più recenti di HA.
        return "€/l"

    @property
    def extra_state_attributes(self) -> Dict[str, Any]:
        data = self.coordinator.data or {}
        fuels = data.get("fuels") or data.get("carburanti") or []
        attrs: Dict[str, Any] = {}
        attrs["station_id"] = self.station_id
        attrs["fuel_name"] = self.fuel_name
        attrs["is_self"] = self.is_self
        attrs["company"] = data.get("company") or data.get("gestore")
        attrs["name"] = data.get("name") or data.get("description")
        attrs["address"] = _format_address(data)

        # trova la voce carburante corrispondente per esporre validityDate e i dati raw
        for f in fuels:
            candidate = f.get("name") or f.get("fuel") or f.get("description")
            candidate_is_self = bool(f.get("isSelf") or f.get("is_self") or False)
            if (not self.fuel_name or str(candidate).lower() == str(self.fuel_name).lower()) and candidate_is_self == self.is_self:
                attrs["raw_fuel"] = f
                validity = f.get("validityDate") or f.get("validity_date")
                if validity:
                    try:
                        # Ci aspettiamo epoch in ms o stringa ISO. Proviamo a parsare in modo robusto.
                        if isinstance(validity, (int, float)):
                            dt = datetime.fromtimestamp(int(validity) / 1000)
                        else:
                            dt = datetime.fromisoformat(str(validity))
                        attrs["validity_date"] = dt.isoformat()
                    except Exception:
                        attrs["validity_date"] = str(validity)
                break

        # Logo del brand (se mappato)
        brand = data.get("brand")
        if brand:
            key = str(brand).lower()
            logo = BRAND_LOGOS.get(key) or BRAND_LOGOS.get(key.split()[0]) or BRAND_LOGOS.get("others")
            if logo:
                attrs["brand_logo"] = f"/local/custom_components/{DOMAIN}/assets/brands/{logo}"
        if not self.available:
            attrs["error"] = "unavailable"
        attrs[ATTR_ATTRIBUTION] = "Dati da Osservaprezzi (MIMIT)"
        return attrs

    @property
    def device_info(self) -> DeviceInfo:
        base_name = self.configured_name or (self.coordinator.data or {}).get("name") or f"Station {self.station_id}"
        identifier = f"{self.entry_id}_{self.station_id}" if getattr(self, "entry_id", None) else str(self.station_id)
        return DeviceInfo(
            identifiers={(DOMAIN, identifier)},
            name=base_name,
            manufacturer=(self.coordinator.data or {}).get("company") or "Osservaprezzi",
        )
